from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.db.database import get_db
from app.schemas.Image import ProductImageCreate, ProductImageUpdate
from app.services.ProductImageService import ProductImageService as imageService
from app.utils.response import ResponseHandler
from app.config.security import check_customer_admin
from fastapi.security.http import HTTPAuthorizationCredentials
from fastapi.security import HTTPBearer
from fastapi import UploadFile, File
from fastapi.responses import FileResponse


router = APIRouter(
    prefix="/product-images",
    tags=["ProductImage"],
    responses={404: {"description": "Not Found"}},
)
auth_scheme = HTTPBearer()

from fastapi import UploadFile, File, HTTPException, Depends
from sqlalchemy.exc import IntegrityError, SQLAlchemyError
import shutil, os
from datetime import datetime

@router.post("/")
async def create_product_image(
    payload: ProductImageCreate,
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    admin_account = Depends(check_customer_admin)
):
    try:
        # Kiểm tra mime-type
        if not file.content_type.startswith("image/"):
            raise HTTPException(status_code=400, detail="File không phải là ảnh")

        # Tạo tên file duy nhất
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        upload_dir = "uploads"
        os.makedirs(upload_dir, exist_ok=True)
        file_path = os.path.join(upload_dir, f"{timestamp}_{file.filename}")

        # Lưu file
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)

        # Gọi service để lưu DB
        out = imageService.create_product_image(db, payload, file_path)

        return ResponseHandler.create_success("ProductImage", out.id, out)

    except IntegrityError as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=f"Lỗi dữ liệu: {str(e.orig)}")

    except SQLAlchemyError as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Lỗi database: {str(e)}")

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Lỗi hệ thống: {str(e)}")



@router.get("/{image_id}")
async def get_product_image(
    image_id: int, 
    db: Session = Depends(get_db)
):
    out = imageService.get_product_image(db, image_id)
    return FileResponse(out.image_path, media_type="image/jpeg")

@router.delete("/{image_id}")
async def delete_product_image(
    image_id: int, 
    db: Session = Depends(get_db),
    admin_account = Depends(check_customer_admin)
):
    return imageService.delete_product_image(db, image_id)


