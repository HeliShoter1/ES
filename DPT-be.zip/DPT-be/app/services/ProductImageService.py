import os
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from app.models.model import ProductImage
from app.schemas.Image import (
    ProductImageCreate,
    ProductImageUpdate,
    ProductImageOut,
)
from app.utils.response import ResponseHandler
from datetime import datetime
from fastapi import UploadFile


class ProductImageService:

    upload_path = "C:\Users\ADMIN\Documents\Đa Phương Tiện\DPT\upload"

    @staticmethod
    def create_product_image(db: Session,file: UploadFile, payload: ProductImageCreate) -> ProductImageOut:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        unique_filename = f"{timestamp}_{os.path.basename(payload.image_path)}"

        save_path = os.path.join(ProductImageService.upload_path, unique_filename)

        with open(save_path, "wb") as buffer:
            buffer.write(file.file.read())

        image = ProductImage(
            product_id=payload.product_id,
            image_path=save_path,
        )

        db.add(image)
        try:
            db.commit()
        except IntegrityError as exc:
            db.rollback()
            raise ResponseHandler.not_found_error(
                "ProductImage create failed",
                str(exc.orig) if hasattr(exc, "orig") else None,
            )
        db.refresh(image)
        return ProductImageService._to_out(image)

    @staticmethod
    def get_product_image(db: Session, image_id: int) -> ProductImageOut:
        image = db.query(ProductImage).filter(ProductImage.id == image_id).first()
        if not image:
            ResponseHandler.not_found_error("ProductImage", image_id)
        return ProductImageService._to_out(image)

    @staticmethod
    def get_image_by_product(db:Session, product_id: int):
        list_image = db.query(ProductImage).filter(ProductImage.product_id == product_id)
        return [ProductImageService._to_out(i) for i in list_image]

    @staticmethod
    def delete_product_image(db: Session, image_id: int):
        image = db.query(ProductImage).filter(ProductImage.id == image_id).first()
        if not image:
            ResponseHandler.not_found_error("ProductImage", image_id)
        os.remove(image.image_path)
        db.delete(image)
        db.commit()
        return ResponseHandler.delete_success("ProductImage", image_id, None)

    @staticmethod
    def _to_out(image: ProductImage) -> ProductImageOut:
        return ProductImageOut(
            id=image.id,
            product_id=image.product_id,
            image_path=image.image_path,
            create_at=image.created_at,
            update_at=image.updated_at,
        )


