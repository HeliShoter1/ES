from enum import Enum

# Enums
class OrderStatus(str, Enum):
    paid = "paid"
    unpaid = "unpaid"
    pending = "pending"
    cancelled = "cancelled"

class EmployeeRole(str, Enum):
    admin = "admin"
    staff = "staff"
    manager = "manager"

class EmployeeActivate(str,Enum):
    activate = True
    non_activate = False