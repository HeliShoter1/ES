from pydantic import BaseModel, Field, EmailStr
from typing import List, Optional
from datetime import datetime

class ProductImageBase(BaseModel):
    product_id: int
    image_path: str

class ProductImageCreate(ProductImageBase):
    pass

class ProductImageUpdate(ProductImageBase):
    pass

class ProductImageOut(ProductImageBase):
    id: int
    create_at: datetime
    update_at: datetime
    
    class Config:
        from_attributes = True